Hello, so this is the code I got done. I am sorry that I didnt get it done once agian. I do not really understand why this would be difficult for me. 

The things I know I needed too do
1.) Import the fitered sphere center to the rotf concept.
2.)With that turn it into usable data.
3.)Implement that information into a spot in the planner.
4.)Create the full planner to get it to work.


I couldnt really get that far. I edited the rotf example and put what I thought would work. Then I translated that into my simple planner to see if that would work. It kind of did but
it would break and just not work. So I would like to meet some time next week a few times to get a full understanding of this and fix this report. Thank you. And sorry to dissapoint.

-Thomas.
